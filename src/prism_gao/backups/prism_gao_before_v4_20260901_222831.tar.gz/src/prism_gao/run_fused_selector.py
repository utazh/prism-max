"""Run the PRISM CLI with optional process-local PRISM-Gao hooks."""

from __future__ import annotations

import os


def main() -> int:
    selector_mode = os.environ.get("PRISM_GAO_SELECTOR_MODE", "exact").strip().lower()
    if selector_mode == "torch":
        # True Stage-A baseline: do not patch QuantizedKeyIndex.load_layer or the
        # Qwen selector scorer.
        if os.environ.get("PRISM_GAO_PRECISION_MODE", "").strip().lower() not in {
            "",
            "off",
            "none",
        }:
            raise ValueError("torch selector mode cannot enable Stage-C hooks")
        if os.environ.get("PRISM_GAO_PERIOD_POLICY", "original").strip().lower() not in {
            "",
            "original",
            "v1",
        } or int(os.environ.get("PRISM_GAO_FIXED_PERIOD", "0") or "0") != 0:
            raise ValueError("torch selector mode is only for the untouched Stage-A baseline")
    else:
        if selector_mode not in {"exact", "direct"}:
            raise ValueError("PRISM_GAO_SELECTOR_MODE must be torch, exact, or direct")
        from .fused_selector_integration import install

        install()

    from contiguous_fuxian.flexgen_qwen_reprefill import main as original_main

    return int(original_main())


if __name__ == "__main__":
    raise SystemExit(main())
